{ config, pkgs, ... }:

{
  services.xmrig = {
    enable = true;
    settings = {

      autosave = true;
      autosave-interval = 300;
      cpu = true;
      opencl = false;
      cuda = false;

      donate-level = 0;
      
      # CPU settings
      cpu-priority = -2;
      cpu-usage = 60;
      # cpu-usage = null;
      threads = 6;
      # threads = null;

      # RandomX optimizations
      randomx = {
        large-pages = true;
        mode = "auto";
        cache = 2;
      };

      pools = [
        {
          # url = "xmr-eu1.nanopool.org:10343";
          url = "pool.hashvault.pro:443";
          # url = "pool.supportxmr.com:8080";
          user = "48rmufMfAAiHH4N8q7wzdrdvcN7AXcgwTN2oEqCrCnBafCeyFaZNjZbG6ytK4BsnpUZnLuRMAstaeSpDs3JKg4qrT3x1K2K";
          pass = "somethingorothjer";
          #algo = "rx/0";
          #algo = "rx";
          keepalive = true;
          tls = true;
        }
      ];
    };
  };

  boot.kernel.sysctl = {
    "vm.nr_hugepages" = 512;  # Set this to the number of huge pages you want
  };

  boot.kernelParams = [
    "hugepagesz=1G"
    "hugepages=4"
    "transparent_hugepage=always"
  ];

  environment.systemPackages = with pkgs; [
    xmrig-proxy
    xprintidle
  ];

}
